import { Injectable } from '@angular/core';
import {
  HttpRequest, // intercetta tutte le chiamate richieste
  HttpHandler, // stream di eventi http
  HttpEvent, //
  HttpInterceptor //per autodenirsi come interceptor
} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable()
export class ErroriInterceptor implements HttpInterceptor {

  constructor() {}

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    return next.handle(request).pipe(catchError(err => {
      return throwError(err)
    }));
  }
}
